
These examples of GERBER files with matching "pick and place".csv file
are intented to demonstrate possible usage of gerbv in PCB assembly
and any other work which requires efficient searching of elements on PCB.

They were donated by Karl Schmittschneider <ks.electronic@t-online.de>
to gerbv project on 2005-04-19.

I have converted all text files from DOS (CRLF) end of line to
UNIX (LF) before checkin.

To test you may load in gerbv SE_SG_IF_V2.{GBO,GTO} files.
Then import Pick_Place_for_SE_SG_IF_V2.csv (main File menu).

Then you may select parts by double click, or with entering the whole
names or partial names and pressing Enter. Once single component is selected
you may go to the next one by pressing Space.

See README-Pick-and-Place-search_parts.txt in the main gerbv source directory.

Please email <T.Motylewski@bfad.de> if you have any questions.
