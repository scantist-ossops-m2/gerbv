Jeremy T Braun sent me a couple of aperture macros that he thought didn't
work in gerbv. He was correct. 

These examples shows that aperture macro primitive 1 is a _filled_ circle
(not that all clear from the specication) and that exposure in aperture
macros is sort of the equivalent to layers in gerber files.

The jpg file is derived from ViewMate and converted from bitmap to jpg
with good old trustworthy xv.

$Id$
