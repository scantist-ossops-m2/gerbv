This is a design from Dino Ghilardi who kindly sent this files to 
debug gerbv. It has examples on negative coordinates and oval 
apertures. ast.ps is a postscript version of rs232_cm.ast.

$Id$
