This file is sent by David Cussans at University of Bristol High Energy 
Physics Group. It contains example on an excessive use of corners 
in polygons, which broke my hardcoded polygon-corner array. It also uses 
millimeters or rather a mixture of millimeters and inches, which still
is unsupported.

After a thorough investigation this file seems to be broken. To be usefull
all apertures should be in millimeters too, despite the file starts with
%MOIN*%. I have changed the first line by hand to get this file to work 
properly.

This also serves as an example file from Mentor Boardstation.

$Id$
