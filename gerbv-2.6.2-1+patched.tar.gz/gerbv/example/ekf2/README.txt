This is a design from Joachim Jansen (EKF Elektronik GmbH Industrial 
Computers & Information Technology) who kindly sent this files to 
debug our design. Don't try to build it; it is broken and will only
serve as a great example on gerber files.

$Id$
