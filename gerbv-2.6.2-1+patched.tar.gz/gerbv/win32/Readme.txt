# $Id$
#

This is the windows port of gerbv, the free open source RS274-X, NC/drill
and xy (centroid) file viewer.

Please visit http://gerbv.sourceforge.net for more information
about gerbv.

The windows port makes use of GTK+ for windows.   Please visit 
http://www.gtk.org for more information about GTK.  Without all the hard
work of the GTK+ authors, gerbv would not exist in its current form.

The windows installer was created with NSIS.  Please visit
http://nsis.sourceforge.net for more information about NSIS.

