#ifndef __LREALPATH_H__
#define __LREALPATH_H__

/* A well-defined realpath () that is always compiled in.  */
char *lrealpath (const char *);

#endif /* __LREALPATH_H__ */


